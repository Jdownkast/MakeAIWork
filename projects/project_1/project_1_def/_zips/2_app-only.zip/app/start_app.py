from webbrowser import open as wb_open

url = "http://127.0.0.1:5000"

wb_open(url)
